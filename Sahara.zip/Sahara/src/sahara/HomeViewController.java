/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sahara;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle; 
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.SplitPane;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;

/**
 * FXML Controller class
 *
 * @author Camilo
 */
public class HomeViewController implements Initializable {
    
    @FXML
    private Button productsbutton;
    @FXML
    private Button accountbutton;
    @FXML
    private Button homebutton;
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }  
    
    public void handleProductsButtonAction(ActionEvent event) throws IOException, Exception{
        makeProductsPage();
    }
    
    public void handleHomeButtonAction(ActionEvent event) throws IOException, Exception{
        
    }
    
    public void handleAccountButtonAction(ActionEvent event) throws IOException, Exception{
        accountScreen();
    }
    private void accountScreen() throws Exception{
        Stage stage = new Stage();
        VBox root = FXMLLoader.load(getClass().getResource("AccountView.fxml"));
        Scene scene= new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    
    public void makeProductsPage(){
        Stage previousstage = (Stage) productsbutton.getScene().getWindow();
        Stage stage = new Stage();
        
        stage.setTitle("Sahara");
        stage.setWidth(820);
        stage.setHeight(680);
 
        final Label label = new Label("Appliances");
        label.setFont(new Font("Arial", 20));
        TableView table = new TableView();
        table.setEditable(true);
 
        TableColumn ProductCol = new TableColumn("Product Name");
        TableColumn PriceCol = new TableColumn("Price");
        TableColumn DetailsCol = new TableColumn("Description");
        ProductCol.setMinWidth(100.0);
        PriceCol.setMinWidth(25.0);
        DetailsCol.setMinWidth(600.0);
        
        
        table.getColumns().addAll(ProductCol, PriceCol, DetailsCol);
 
        final VBox vbox = new VBox();
        vbox.setSpacing(5);
        vbox.setAlignment(Pos.CENTER);
        vbox.setPadding(new Insets(10, 0, 0, 10));
        vbox.getChildren().addAll(label, table);
        HBox hbox = new HBox();
        hbox.setAlignment(Pos.CENTER);
        hbox.setSpacing(20.0);
        hbox.getChildren().addAll(homebutton, productsbutton, accountbutton);
        VBox mainvbox = new VBox();
        mainvbox.setAlignment(Pos.CENTER);
        mainvbox.getChildren().addAll(hbox, vbox);
        Scene scene = new Scene(mainvbox);
        stage.setScene(scene);
        stage.show();
        previousstage.close();
        
    }
    
    
}
