/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sahara;

/**
 *
 * @author Tina
 */
import java.sql.*;
public class connectSQL {
    Connection con = null;
    public static Connection connectDB(){
        try
        {
            Class.forName("org.sqlite.JDBC");
            Connection con = DriverManager.getConnection("jdbc:sqlite:C:/Users/Tina/Documents/NetBeansProjects/Sahara");
            return con;
        }
        catch(Exception ee)
        {
            ee.printStackTrace();
            return null;
        }
    }
}
