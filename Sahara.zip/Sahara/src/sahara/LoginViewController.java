/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sahara;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Button;
import java.io.IOException;
import javafx.stage.*;
import javafx.scene.Parent;
import javafx.scene.Scene;

/**
 * FXML Controller class
 *
 * @author Camilo
 */
public class LoginViewController implements Initializable {

    /**
     * Initializes the controller class.
     */
    
    @FXML
    private Button loginbutton; 
    
    @FXML
    private void handleLoginButtonAction(ActionEvent event) throws IOException{
        Stage stage;
        Parent root;
        if(event.getSource()==loginbutton){
            //get reference to the home stage
            stage=(Stage) loginbutton.getScene().getWindow();
            //load Home FXML doc
            root = FXMLLoader.load(getClass().getResource("HomeView.fxml"));
        } else {
            stage = new Stage();
            root = FXMLLoader.load(getClass().getResource("LoginView.fxml"));
        }
        stage.setTitle("Sahara Home");
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
