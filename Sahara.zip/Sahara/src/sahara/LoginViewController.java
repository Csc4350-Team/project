/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sahara;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.*;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.event.*;
import javafx.scene.layout.GridPane;
/**
 * FXML Controller class
 *
 * @author Tina
 */
public class LoginViewController implements Initializable {

    @FXML
    private TextField email;
    @FXML
    private PasswordField password;
    @FXML
    private Button loginbutton;
    @FXML
    private Button createaccountbutton;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void handleLoginButtonAction(ActionEvent event) throws Exception{
       if(validateEmail(email) && validatePassword(password)){
           homeScreen();
       } else {
        String message = "Didn't recognize email and password pair.";
        String title = "Login Error";
       AlertBox.popUp(title, message);
       }
    }
    
    private void homeScreen() throws Exception {
        Stage stage = new Stage();
        GridPane root = FXMLLoader.load(getClass().getResource("HomeView.fxml"));
        Scene scene= new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    
    private boolean validateEmail(TextField email){
        boolean at = false;
        boolean ext = false;
        String emailtext = email.getText();
        String extension;
        if(emailtext.length() > 7){
            extension = email.getText(emailtext.length()-4, emailtext.length());
            for(int i = 0; i < emailtext.length(); i++ ){
                if(emailtext.charAt(i)=='@'){
                    at = true;
                    break;
                }
            }
            System.out.println(extension);
            if (extension.equals(".com")|| extension.equals(".net")||extension.equals(".org")||extension.equals(".edu")){
                ext = true;
            }
        } 
        return at && ext;
    }
    
    @FXML
    private void handleCreateAccountButtonAction(ActionEvent event) throws Exception {
        Stage stage = new Stage();
        GridPane root = FXMLLoader.load(getClass().getResource("SignUp.fxml"));
        Scene scene= new Scene(root);
        stage.setScene(scene);
        stage.showAndWait();        
    }
    
    private boolean validatePassword(PasswordField password){
        return true;
    }
    
    private void invalidEntry(){
        String message = "Didn't recognize email and password pair.";
        String title = "Login Error";
        AlertBox.popUp(title, message);
    }
}