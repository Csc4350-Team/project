/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sahara;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.*;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.event.*;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
/**
 * FXML Controller class
 *
 * @author Tina
 */
public class LoginViewController implements Initializable {

    @FXML
    private TextField email;
    @FXML
    private PasswordField password;
    @FXML
    private Button loginbutton;
    @FXML
    private Button createaccountbutton;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void handleLoginButtonAction(ActionEvent event) throws Exception{
       if(validateEmail(email) && validatePassword(password)){
           Stage stage = (Stage) loginbutton.getScene().getWindow();
           homeScreen();
           stage.close();
       } else {
        String message = "Didn't recognize email and password pair.";
        String title = "Login Error";
       AlertBox.popUp(title, message);
       }
    }
    
    private void homeScreen() throws Exception {
        Stage stage = new Stage();
        GridPane root = FXMLLoader.load(getClass().getResource("HomeView.fxml"));
        Scene scene= new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    
    private boolean validateEmail(TextField email){
        boolean at = false;
        boolean ext = false;
        String emailtext = email.getText();
        String extension;
        if(emailtext.length() > 7){
            extension = email.getText(emailtext.length()-4, emailtext.length());
            for(int i = 0; i < emailtext.length(); i++ ){
                if(emailtext.charAt(i)=='@'){
                    at = true;
                    break;
                }
            }
            System.out.println(extension);
            if (extension.equals(".com")|| extension.equals(".net")||extension.equals(".org")||extension.equals(".edu")){
                ext = true;
            }
        } 
        return at && ext;
    }
    
    @FXML
    private void handleCreateAccountButtonAction(ActionEvent event) throws Exception {
        Stage stage = new Stage();
        stage.setTitle("Sign In to Sahara");
        GridPane root = new GridPane();
        root.setAlignment(Pos.CENTER);
        Label headinglabel = new Label("Join the Community");
        Label firstnamelabel= new Label("First Name");
        Label lastnamelabel= new Label("Last Name");
        Label emaillabel= new Label("Email");
        Label passwordlabel= new Label("Password");
        Label confirmpasswordlabel = new Label("Confirm Password");
        Label phonelabel= new Label("Phone");
        TextField firstnamefield = new TextField();
        TextField lastnamefield = new TextField();
        TextField emailfield = new TextField();
        TextField passwordfield = new TextField();
        TextField confirmpasswordfield = new TextField();
        TextField phonefield = new TextField();
        Button signupbutton = new Button("Create Account");
        
        root.setVgap(10);
        root.setHgap(10);
        root.add(headinglabel, 0, 0);
        root.add(firstnamelabel, 0, 1);
        root.add(lastnamelabel, 1, 1);
        root.add(emaillabel, 0, 5);
        root.add(passwordlabel, 0, 3);
        root.add(confirmpasswordlabel, 1, 3);
        root.add(phonelabel, 1, 5);
        
        root.add(firstnamefield, 0, 2);
        root.add(lastnamefield, 1, 2);
        root.add(emailfield, 0, 6);
        root.add(phonefield, 1, 6);
        root.add(passwordfield, 0, 4);
        root.add(confirmpasswordfield, 1, 4);
        
        root.add(signupbutton, 0, 7);
   
        
        stage.initModality(Modality.APPLICATION_MODAL);
        stage.setTitle("Sign Up with Sahara");

        signupbutton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent e) {
                stage.close();
            }
        });
        Scene scene= new Scene(root);
        stage.setScene(scene);
        stage.showAndWait();  
    }
    
    private boolean validatePassword(PasswordField password){
        return true;
    }
    
    private void invalidEntry(){
        String message = "Didn't recognize email and password pair.";
        String title = "Login Error";
        AlertBox.popUp(title, message);
    }
}