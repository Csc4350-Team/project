/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sahara;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.*;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.event.*;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
/**
 * FXML Controller class
 *
 * @author Tina
 */
public class LoginViewController implements Initializable {

    @FXML
    private TextField email;
    @FXML
    private PasswordField password;
    @FXML
    private Button loginbutton;
    @FXML
    private Button createaccountbutton;

    /**
     * Initializes the controller class.
     */
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }  


    @FXML
    private void handleLoginButtonAction(ActionEvent event) throws Exception{
       if(validateEmail(email) && validatePassword(password)){
           Stage stage = (Stage) loginbutton.getScene().getWindow();
           homeScreen();
           stage.close();
       } else {
        invalidEntry();
       }
    }

    private void homeScreen() throws Exception {
        Stage stage = new Stage();
        GridPane root = FXMLLoader.load(getClass().getResource("HomeView.fxml"));
        Scene scene= new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    
    private boolean validateEmail(TextField email){
        boolean at = false;
        boolean ext = false;
        String emailtext = email.getText();
        String extension;
        if(emailtext.length() > 7){
            extension = email.getText(emailtext.length()-4, emailtext.length());
            for(int i = 0; i < emailtext.length(); i++ ){
                if(emailtext.charAt(i)=='@'){
                    at = true;
                    break;
                }
            }
            System.out.println(extension);
            if (extension.equals(".com")|| extension.equals(".net")||extension.equals(".org")||extension.equals(".edu")){
                ext = true;
            }
        } 
        return at && ext;
    }
    
    @FXML
    private void handleCreateAccountButtonAction(ActionEvent event) throws Exception {
           createAccountScreen();
    }
    
    private void createAccountScreen() {
        Stage stage = new Stage();
        stage.initModality(Modality.APPLICATION_MODAL);
        stage.setTitle("Create Account");
        stage.setWidth(820.0);
        stage.setHeight(620.0);
        
        Label firstnamelabel = new Label("First Name: ");
        Label lastnamelabel = new Label("Last Name: ");
        Label pwlabel = new Label("Password: ");
        Label cfpwlabel = new Label("Confirm Password: ");
        Label emaillabel = new Label("Email: ");
        Label addresslabel = new Label("Address: ");
        Label phonelabel = new Label("Phone: ");
        
        TextField fnfield = new TextField();
        TextField lnfield = new TextField();
        PasswordField pwfield = new PasswordField();
        PasswordField cfpwfield = new PasswordField();
        TextField emailfield = new TextField();
        TextField addressfield = new TextField();
        TextField phonefield = new TextField();
        
        GridPane root = new GridPane();
        root.setAlignment(Pos.CENTER);
        root.setPadding(new Insets(25));
        
        root.add(firstnamelabel, 0, 0);
        root.add(lastnamelabel, 0, 1);
        root.add(pwlabel, 0, 2);
        root.add(cfpwlabel, 0, 3);
        root.add(emaillabel, 0, 4);
        root.add(addresslabel, 0, 5);
        root.add(phonelabel, 0, 6);
        
        root.add(fnfield, 1, 0);
        root.add(lnfield, 1, 1);
        root.add(pwfield, 1, 2);
        root.add(cfpwfield, 1, 3);
        root.add(emailfield, 1, 4);
        root.add(addressfield, 1, 5);
        root.add(phonefield, 1, 6);
        
        Button signupbutton = new Button("Finish");
        root.add(signupbutton, 0, 7);
        
        
        signupbutton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent e) {
                stage.close();
            }
        });
        
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.showAndWait();
        
        
    }
    
    private boolean validatePassword(PasswordField password){
        return true;
    }
    
    private void invalidEntry(){
        String message = "Didn't recognize email and password pair.";
        String title = "Login Error";
        AlertBox.popUp(title, message);
    }
    public void handleEnterKey(ActionEvent event) throws IOException, Exception{
        password.setOnKeyPressed(new EventHandler<KeyEvent>() {
            @Override
            public void handle(KeyEvent keyEvent){
                if(keyEvent.getCode() == KeyCode.ENTER) {
                    String pw = password.getText();
                    String eml = email.getText();
                }
                       if(validateEmail(email) && validatePassword(password)){
                        Stage stage = (Stage) loginbutton.getScene().getWindow();
                    try {
                        homeScreen();
                    } catch (Exception ex) {
                        Logger.getLogger(LoginViewController.class.getName()).log(Level.SEVERE, null, ex);
                    }
                        stage.close();
                    } else {
                     invalidEntry();
                    }
            }
        });
        
    }
}