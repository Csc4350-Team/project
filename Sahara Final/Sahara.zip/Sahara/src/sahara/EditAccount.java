/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sahara;

import java.io.IOException;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;

/**
 *
 * @author Tina
 */
public class EditAccount {
    

        
  public static void editAccountAction(ActionEvent event) throws IOException{
        Stage stage = new Stage();
        stage.initModality(Modality.APPLICATION_MODAL);
        stage.setTitle("Edit Account");
        stage.setMinWidth(250);
        
        Label label = new Label();
        label.setText("Are you sure you sure?");
        Button no = new Button("No");
        Button yes = new Button("Yes");
        
        no.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent e) {
                stage.close();
            }
        });
      
        yes.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent e) {
                String title ="Edit Account";
                String message = "Changes have been saved.";
                stage.close();
                AlertBox.popUp(title, message);
            }
        });
                
        VBox layout = new VBox(10);
        layout.getChildren().addAll(label, yes, no);
        layout.setAlignment(Pos.CENTER);
        
        Scene scene = new Scene(layout);
        stage.setScene(scene);
        stage.showAndWait(); 
    }
       
public static void deleteAccountAction(ActionEvent event) throws IOException {
        
        Stage stage = new Stage();
        stage.initModality(Modality.APPLICATION_MODAL);
        stage.setTitle("Delete Account");
        stage.setMinWidth(250);
        
        Label label = new Label();
        label.setText("Are you sure you sure?");
        Button no = new Button("No");
        Button yes = new Button("Yes");
        
        no.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent e) {
                stage.close();
            }
        });
        
        yes.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent e) {
                String title ="Delete Account";
                String message = "Account has been deleted.";
                stage.close();
                AlertBox.popUp(title, message);
            }
        });
        
        VBox layout = new VBox(10);
        layout.getChildren().addAll(label, yes, no);
        layout.setAlignment(Pos.CENTER);
        
        Scene scene = new Scene(layout);
        stage.setScene(scene);
        stage.showAndWait();
    }
    
    
}