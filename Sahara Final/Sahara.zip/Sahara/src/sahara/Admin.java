package sahara;


import java.net.URL;
import java.util.ResourceBundle;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.stage.Stage;

 
public class Admin implements Initializable  {
 
        private TableView<Admin.ProductAdmin> table = new TableView<Admin.ProductAdmin>();
    private final ObservableList<Admin.ProductAdmin> data =
        FXCollections.observableArrayList(
                //Grab from database
            new Admin.ProductAdmin(connectSQL.getProd(1), Integer.toString(connectSQL.getPrice(1)), connectSQL.getDesc(1)),
            new Admin.ProductAdmin(connectSQL.getProd(2), Integer.toString(connectSQL.getPrice(2)), connectSQL.getDesc(2)),
            new Admin.ProductAdmin(connectSQL.getProd(3), Integer.toString(connectSQL.getPrice(3)), connectSQL.getDesc(3)),
            new Admin.ProductAdmin(connectSQL.getProd(4), Integer.toString(connectSQL.getPrice(4)), connectSQL.getDesc(4))
        );   
        final HBox hb = new HBox();
 

    public void AdminProduct(Stage stage) {
        Scene scene = new Scene(new Group());
        
        stage.setTitle("Sahara");
        stage.setWidth(820);
        stage.setHeight(680);
 
        final Label label = new Label("Appliances");
        label.setFont(new Font("Arial", 20));
        
        table.setEditable(true);
        
       TableColumn productNameCol = new TableColumn("Product Name");
        productNameCol.setCellValueFactory(new PropertyValueFactory<Admin.ProductAdmin,String>("productName"));

        TableColumn priceCol = new TableColumn("Price");
        priceCol.setCellValueFactory(
            new PropertyValueFactory<Admin.ProductAdmin,String>("price")
        );

        TableColumn detailsCol = new TableColumn("Details");
        detailsCol.setMinWidth(600);
        detailsCol.setCellValueFactory(
            new PropertyValueFactory<Admin.ProductAdmin,String>("details")
        );
                                     
        table.setItems(data);
        table.getColumns().addAll(productNameCol, priceCol, detailsCol);
     
        final TextField addProductName = new TextField();
        addProductName.setPromptText("Products Name");
        addProductName.setMaxWidth(productNameCol.getPrefWidth());
        final TextField addPriceName = new TextField();
        addPriceName.setMaxWidth(priceCol.getPrefWidth());
        addPriceName.setPromptText("Price Name");
        final TextField addDetails = new TextField();
        addDetails.setMaxWidth(detailsCol.getPrefWidth());
        addDetails.setPromptText("Details");
 
        final Button addButton = new Button("Add Product");
        addButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent e) {
                data.add(new ProductAdmin(
                        addProductName.getText(),
                        addPriceName.getText(),
                        addDetails.getText()));
                addProductName.clear();
                addPriceName.clear();
                addDetails.clear();
            }
        });
 
        hb.getChildren().addAll(addProductName, addPriceName, addDetails, addButton);
        hb.setSpacing(3);
        
        
        final VBox vbox = new VBox();
        vbox.setSpacing(5);
        vbox.setPadding(new Insets(10, 0, 0, 10));
        vbox.getChildren().addAll(table);




        
        VBox mainvbox = new VBox();
        mainvbox.setAlignment(Pos.CENTER);
        mainvbox.getChildren().addAll(vbox);
        
        ((Group) scene.getRoot()).getChildren().addAll(mainvbox);
        stage.setScene(scene);
        stage.show();           
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
 
public static class ProductAdmin {
        private final SimpleStringProperty productName;
        private final SimpleStringProperty price;
        private final SimpleStringProperty details;

        private ProductAdmin(String pName, String priceValue, String details) {
            this.productName = new SimpleStringProperty(pName);
            this.price = new SimpleStringProperty(priceValue);
            this.details = new SimpleStringProperty(details);
        }

        public String getProductAdminName() {
            return productName.get();
        }
        public void setProductAdminName(String pName) {
            productName.set(pName);
        }
       
        public String getPrice() {
            return price.get();
        }
        public void setPrice(String pName) {
            price.set(pName);
        }
       
        public String getDetails() {
            return details.get();
        }
        public void setDetails(String pName) {
            details.set(pName);
        }
       
    }
} 
