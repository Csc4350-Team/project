/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sahara;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle; 
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.SplitPane;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import static javax.management.Query.value;

/**
 * FXML Controller class
 *
 * @author Camilo
 */
public class HomeViewController implements Initializable {
    
    @FXML
    private Button productsbutton;
    @FXML
    private Button accountbutton;
    @FXML
    private Button homebutton;
    
        private TableView<Product> table = new TableView<Product>();
    private final ObservableList<Product> data =
        FXCollections.observableArrayList(
                //Grab from database
            new Product(connectSQL.getProd(1), Integer.toString(connectSQL.getPrice(1)), connectSQL.getDesc(1)),
            new Product(connectSQL.getProd(2), Integer.toString(connectSQL.getPrice(2)), connectSQL.getDesc(2)),
            new Product(connectSQL.getProd(3), Integer.toString(connectSQL.getPrice(3)), connectSQL.getDesc(3)),
            new Product(connectSQL.getProd(4), Integer.toString(connectSQL.getPrice(4)), connectSQL.getDesc(4))
        );   


    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {

    }  
    
    public void handleProductsButtonAction(ActionEvent event) throws IOException, Exception{
        makeProductsPage();
    }
    
    public void handleHomeButtonAction(ActionEvent event) throws IOException, Exception{
        
    }
    
    public void handleAccountButtonAction(ActionEvent event) throws IOException, Exception{
        accountScreen();
    }
    private void accountScreen() throws Exception{
        Stage stage = new Stage();
        VBox root = FXMLLoader.load(getClass().getResource("AccountView.fxml"));
        Scene scene= new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    
    public void makeProductsPage(){
        Stage previousstage = (Stage) productsbutton.getScene().getWindow();
        Stage stage = new Stage();
        Scene scene = new Scene(new Group());
        
        stage.setTitle("Sahara");
        stage.setWidth(820);
        stage.setHeight(680);
 
        final Label label = new Label("Appliances");
        label.setFont(new Font("Arial", 20));
        
        table.setEditable(true);
        
       TableColumn productNameCol = new TableColumn("Product Name");
        productNameCol.setCellValueFactory(new PropertyValueFactory<Product,String>("productName"));

        TableColumn priceCol = new TableColumn("Price");
        priceCol.setCellValueFactory(
            new PropertyValueFactory<Product,String>("price")
        );

        TableColumn detailsCol = new TableColumn("Details");
        detailsCol.setMinWidth(600);
        detailsCol.setCellValueFactory(
            new PropertyValueFactory<Product,String>("details")
        );
                                     
        table.setItems(data);
        table.getColumns().addAll(productNameCol, priceCol, detailsCol);
     
        final Button addButton = new Button("Add");
        addButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override public void handle(ActionEvent e) {
                data.add(new Product("new","new","new"));
            }
        });
        
        
        final VBox vbox = new VBox();
        vbox.setSpacing(5);
        vbox.setPadding(new Insets(10, 0, 0, 10));
        vbox.getChildren().addAll(table);




        
        

        HBox hbox = new HBox();
        hbox.setAlignment(Pos.CENTER);
        hbox.setSpacing(20.0);
        hbox.getChildren().addAll(homebutton, productsbutton, accountbutton);
        VBox mainvbox = new VBox();
        mainvbox.setAlignment(Pos.CENTER);
        mainvbox.getChildren().addAll(hbox, vbox);
        
        ((Group) scene.getRoot()).getChildren().addAll(mainvbox);
        stage.setScene(scene);
        stage.show();
        previousstage.close();
        
    }
    
    public static class Product {
        private final SimpleStringProperty productName;
        private final SimpleStringProperty price;
        private final SimpleStringProperty details;

        private Product(String pName, String priceValue, String details) {
            this.productName = new SimpleStringProperty(pName);
            this.price = new SimpleStringProperty(priceValue);
            this.details = new SimpleStringProperty(details);
        }

        public String getProductName() {
            return productName.get();
        }
        public void setProductName(String pName) {
            productName.set(pName);
        }
       
        public String getPrice() {
            return price.get();
        }
        public void setPrice(String pName) {
            price.set(pName);
        }
       
        public String getDetails() {
            return details.get();
        }
        public void setDetails(String pName) {
            details.set(pName);
        }
       
    }
    
    
}
